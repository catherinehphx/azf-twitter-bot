# @HerrKlinkerhof3
## name: HerrKlinkerhofen
A twitter bot that serves as notifier for the recent #js #javascript #nodejs #reactjs news.

![Image of the app](https://github.com/mihailgaberov/twitter-bot/blob/master/twitter-bot-screenshot.png)


Read how I built it in this [Medium article here](https://medium.com/@mihailgaberov/creating-a-twitter-bot-in-5am-2a42a9920e67).

Read how I polished it with MongodDB in this [second article](https://itnext.io/improve-your-twitter-bot-with-mongodb-1f1e51e632d4).
